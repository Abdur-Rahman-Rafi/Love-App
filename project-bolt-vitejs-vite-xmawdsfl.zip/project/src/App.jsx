import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-scroll';
import { VerticalTimeline, VerticalTimelineElement } from 'react-vertical-timeline-component';
import 'react-vertical-timeline-component/style.min.css';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import Slider from 'react-slick';

const photos = [
  'https://images.pexels.com/photos/1024969/pexels-photo-1024969.jpeg',
  'https://images.pexels.com/photos/1415131/pexels-photo-1415131.jpeg',
  'https://images.pexels.com/photos/1024993/pexels-photo-1024993.jpeg'
];

const timelineEvents = [
  {
    date: 'January 15, 2023',
    title: 'First Meeting',
    description: 'The day our eyes met and hearts connected.'
  },
  {
    date: 'February 14, 2023',
    title: 'First Date',
    description: 'Our magical first date under the starlit sky.'
  },
  {
    date: 'January 15, 2024',
    title: 'One Year Anniversary',
    description: 'Celebrating one year of pure love and happiness.'
  }
];

function App() {
  const [isPlaying, setIsPlaying] = useState(false);

  useEffect(() => {
    const createHeart = () => {
      const heart = document.createElement('div');
      heart.className = 'heart';
      heart.style.left = Math.random() * 100 + 'vw';
      document.querySelector('.floating-hearts').appendChild(heart);
      setTimeout(() => heart.remove(), 4000);
    };

    const interval = setInterval(createHeart, 300);
    return () => clearInterval(interval);
  }, []);

  const sliderSettings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 3000
  };

  return (
    <div className="relative">
      <div className="floating-hearts" />
      
      <nav className="fixed top-0 w-full bg-white/80 backdrop-blur-sm shadow-md z-50">
        <div className="container mx-auto px-4 py-4 flex justify-center space-x-6">
          {['Home', 'Our Story', 'Gallery', 'Love Letter', 'Timeline'].map((item) => (
            <Link
              key={item}
              to={item.toLowerCase().replace(' ', '-')}
              smooth={true}
              duration={500}
              className="nav-link"
            >
              {item}
            </Link>
          ))}
        </div>
      </nav>

      <section id="home" className="section pt-32">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="container mx-auto text-center"
        >
          <h1 className="text-5xl font-bold text-primary mb-8">
            Srabony Mim
          </h1>
          <div className="max-w-3xl mx-auto">
            <Slider {...sliderSettings}>
              {photos.map((photo, index) => (
                <div key={index} className="px-2">
                  <img
                    src={photo}
                    alt={`Us ${index + 1}`}
                    className="rounded-lg shadow-xl w-full h-[500px] object-cover"
                  />
                </div>
              ))}
            </Slider>
          </div>
        </motion.div>
      </section>

      <section id="love-letter" className="section bg-white">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 1 }}
          className="container mx-auto max-w-2xl text-center"
        >
          <h2 className="text-4xl font-bold mb-8">My Love Letter to You</h2>
          <p className="text-lg leading-relaxed">
            Dear Srabony,<br /><br />
            Every moment with you feels like a beautiful dream come true.
            Your smile lights up my world, and your love makes my heart complete.
            You are my sunshine, my happiness, and my everything.<br /><br />
            Forever yours,<br />
            [Your Name]
          </p>
        </motion.div>
      </section>

      <section id="timeline" className="section">
        <div className="container mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12">Our Journey</h2>
          <VerticalTimeline>
            {timelineEvents.map((event, index) => (
              <VerticalTimelineElement
                key={index}
                date={event.date}
                iconStyle={{ background: 'var(--primary-color)', color: '#fff' }}
                contentStyle={{ background: '#fff', color: '#2f3542' }}
              >
                <h3 className="text-xl font-bold">{event.title}</h3>
                <p>{event.description}</p>
              </VerticalTimelineElement>
            ))}
          </VerticalTimeline>
        </div>
      </section>

      <footer className="bg-white py-8 text-center">
        <p className="text-lg italic">"Forever Yours, [Your Name]"</p>
        <audio
          controls
          className="mt-4"
          onPlay={() => setIsPlaying(true)}
          onPause={() => setIsPlaying(false)}
        >
          <source src="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3" type="audio/mpeg" />
        </audio>
      </footer>
    </div>
  );
}

export default App;